// Replace these with your own API key and channel ID
const API_KEY = 'YOUR_API_KEY';
const CHANNEL_ID = 'YOUR_CHANNEL_ID';

const videoContainer = document.getElementById('video-container');
const shortsContainer = document.getElementById('shorts-container');

async function fetchVideos() {
    try {
        const res = await fetch(`https://www.googleapis.com/youtube/v3/search?key=${API_KEY}&channelId=${CHANNEL_ID}&part=snippet&order=date&maxResults=12`);
        const data = await res.json();
        data.items.forEach(item => {
            if(item.id.videoId){
                const videoId = item.id.videoId;
                const title = item.snippet.title;
                const card = document.createElement('div');
                card.className = 'video-card';
                card.innerHTML = `<iframe src="https://www.youtube.com/embed/${videoId}" allowfullscreen></iframe>
                                  <h3>${title}</h3>`;
                videoContainer.appendChild(card);
            }
        });
    } catch (error) {
        console.error('Error fetching videos:', error);
    }
}

fetchVideos();